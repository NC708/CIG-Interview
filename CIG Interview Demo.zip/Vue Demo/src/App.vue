<template>
  <img alt="Logo not found" src="./assets/TopLogo.png">
  <Header>
    <Button @click="picker1" text = "Food"/>
    <Button @click="picker2" text = "Books"/>
    <Button @click="picker3" text = "Animals"/>
  </Header>
  <p>
    {{result}}
  </p>
</template>

<script>
import Button from './components/Button.vue'

export default 
{
  name: 'App',
  components: {
    Button
  },
  data() {
    return {
      Food: ['Pizza', 'Sushi', 'Hamburger', 'Hot Dog', 'Oatmeal'],
      Books: ['Dracula', 'Hunger Games', 'The Odyssey', 'The Divine Comedy', 'Harry Potter'],
      Animals: ['Horse','Dog','Cat','Mouse','Sheep','Fox','Gorilla'],
      result: '',
    }
  },
  methods: {
    picker1() {
      var chosenNumber1 = Math.floor(Math.random() * this.Food.length);
      this.result = this.Food[chosenNumber1]
    },
    picker2() {
      var chosenNumber2 = Math.floor(Math.random() * this.Books.length);
      this.result = this.Books[chosenNumber2]
    },
    picker3() {
      var chosenNumber3 = Math.floor(Math.random() * this.Animals.length);
      this.result = this.Animals[chosenNumber3]
    }
  }
}
</script>

<style>
img {
  height: 100px;
}
p {
font-size: 65px;
color: black;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #097cf0;
  margin-top: 60px;
}
</style>