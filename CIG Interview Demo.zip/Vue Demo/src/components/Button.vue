<template>
  <button class="btn">
    {{text}}
  </button>
</template>

<script>

export default 
{
  name: 'Button',
  props:
  {
    text: String,
  },
}
</script>

<style scoped>
button
{
  border-radius: 8px;
  margin: 20px;
  width: 110px;
  height: 40px;
  Font-size: 25px;
  background-color: #000000;
  border: none;
  color: white;
}
</style>