#include <iostream>
using namespace std;

int* dijkstra(int** map, int vertCount)	// Takes "map" array of any length and outputs array containing order of shortest path
{										// through all nodes. Also prints node path order and total distance traveled.
	bool* visited = new bool[vertCount] {false};
	int* path = new int[vertCount];
	int totDist = 0;
	visited[0] = true;
	int currVert = 0;
	cout << "Vert " << 0 << " is: " << currVert << endl;
	path[0] = currVert;
	for (int i = 0; i < vertCount - 1; i++) // Iterates until all vertices have had a chance to be visited.
	{
		int localMin = 0;
		int nextVert = 0;
		for (int j = 0; j < vertCount; j++) // Iterates through all  potentially connected vertices.
		{
			if (!visited[j] && map[j][currVert] && (map[j][currVert] < localMin || !localMin))
			{
				localMin = map[j][currVert];
				nextVert = j;
			}
		}
		visited[nextVert] = true;
		currVert = nextVert;
		totDist += localMin;
		if (nextVert == 0)
		{
			cout << "Stuck at local minimum. (No unvisited verteces around)" << endl; // Algo does not back track when reaching a dead end.
			break;
		}
		cout << "Vert " << i + 1 << " is: " << currVert << endl;
		path[i + 1] = currVert;
	}
	cout << "Total path distance is: " << totDist << endl;
	return path;
}

void main()
{
	// Following code initializes a dynamic array.
	const int vertCount = 5;
	int initializer[vertCount][vertCount] = { { 0,4,9,8,3 },{ 4,0,0,7,8 },{ 9,0,0,6,6 },{ 8,7,6,0,2 },{ 3,8,6,2,0 } };	// Rows represent distances to other veritces,
	int** map = new int*[vertCount];																					// Columns represent the vertex in question.
	for (int i = 0; i < vertCount; ++i)																					// "0" means not connected.
	{
		map[i] = new int[vertCount];
		map[i] = initializer[i];
	}
	// End of initialization.
	dijkstra(map, vertCount);
	int hold;
	cin >> hold;
}